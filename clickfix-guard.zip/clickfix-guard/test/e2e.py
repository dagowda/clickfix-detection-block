"""End-to-end test of the unpacked extension with Playwright.

    python -m venv .venv
    .venv/Scripts/pip install playwright
    .venv/Scripts/python -m playwright install chromium
    .venv/Scripts/python test/e2e.py

Loads the extension folder into Playwright's Chromium, serves the folder over HTTP,
runs the engine tests, opens the demo page and the lure simulation, clicks every copy
button with a real user gesture, reads the clipboard back and inspects the service worker's stored detections.
Exit code 1 if any expectation fails.
"""
import functools
import http.server
import json
import os
import sys
import tempfile
import threading

from playwright.sync_api import sync_playwright

EXT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PORT = 8766
ORIGIN = f"http://127.0.0.1:{PORT}"
WARN = "BLOCKED by"

handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=EXT)
srv = http.server.ThreadingHTTPServer(("127.0.0.1", PORT), handler)
srv.daemon_threads = True
threading.Thread(target=srv.serve_forever, daemon=True).start()

out = {"console": [], "pageerrors": []}
tmp = tempfile.mkdtemp(prefix="cfg-e2e-")
with sync_playwright() as p:
    ctx = p.chromium.launch_persistent_context(
        user_data_dir=tmp, channel="chromium", headless=True,
        args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"],
    )
    ctx.grant_permissions(["clipboard-read", "clipboard-write"], origin=ORIGIN)
    sw = ctx.service_workers[0] if ctx.service_workers else ctx.wait_for_event("serviceworker", timeout=15000)
    out["service_worker"] = sw.url

    # 1. engine tests page
    page = ctx.new_page()
    page.on("console", lambda m: out["console"].append(f"[{m.type}] {m.text}"))
    page.on("pageerror", lambda e: out["pageerrors"].append(str(e)))
    page.goto(f"{ORIGIN}/test/run-tests.html")
    page.wait_for_function("document.documentElement.getAttribute('data-tests')", timeout=15000)
    out["engine_tests"] = page.inner_text("#summary")

    # 2. demo page: page banner, four copy paths, benign control
    page.goto(f"{ORIGIN}/test/demo-page.html")
    try:
        page.wait_for_selector("clickfix-guard-banner", state="attached", timeout=10000)
        out["page_banner_present"] = True
    except Exception:
        out["page_banner_present"] = False
    page.evaluate("(() => { const b = document.querySelector('clickfix-guard-banner'); if (b) b.remove(); })()")

    clip = {}
    for b in ["b1", "b2", "b3", "b4", "b5"]:
        page.evaluate("navigator.clipboard.writeText('RESET')")
        page.click("#" + b)
        page.wait_for_timeout(600)
        clip[b] = page.evaluate("navigator.clipboard.readText()")
    out["clipboard_after_click"] = clip
    out["block_banner_present"] = page.evaluate("!!document.querySelector('clickfix-guard-banner')")

    # 3. lure simulation: shipped detection rules (not the self-test tokens)
    page.goto(f"{ORIGIN}/test/lure-sim.html")
    try:
        page.wait_for_selector("clickfix-guard-banner", state="attached", timeout=10000)
        out["sim_page_banner_present"] = True
    except Exception:
        out["sim_page_banner_present"] = False
    page.evaluate("(() => { const b = document.querySelector('clickfix-guard-banner'); if (b) b.remove(); })()")
    sim = {}
    for b in ["s1", "s2", "s3", "s4", "s5", "s6", "s7"]:
        page.evaluate("navigator.clipboard.writeText('RESET')")
        page.click("#" + b)
        page.wait_for_timeout(600)
        sim[b] = page.evaluate("navigator.clipboard.readText()")
    out["sim_clipboard_after_click"] = sim
    out["sim_control_expected"] = page.evaluate("window.__SAMPLES.s7")

    dets = sw.evaluate("() => new Promise(r => chrome.storage.local.get(['detections','unread'], v => r(v)))")
    out["unread"] = dets.get("unread")
    out["detections"] = [
        {k: d.get(k) for k in ("type", "method", "score", "signals", "blocked", "tabUrl", "isTopFrame")}
        for d in dets.get("detections", [])
    ]
    ctx.close()

print(json.dumps(out, indent=2))

problems = []
if not str(out["engine_tests"]).startswith("PASSED"):
    problems.append("engine tests failed")
if not out["page_banner_present"]:
    problems.append("page banner missing")
if not out["block_banner_present"]:
    problems.append("block banner missing")
for b in ["b1", "b2", "b3", "b4"]:
    if not out["clipboard_after_click"][b].startswith(WARN):
        problems.append(f"{b} was not blocked")
if out["clipboard_after_click"]["b5"] != "git status":
    problems.append("benign control was altered")
methods = {d["method"] for d in out["detections"] if d["type"] == "clipboard"}
for m in ["clipboard.writeText", "clipboard.write[text/plain]", "execCommand(copy)", "clipboardData.setData"]:
    if m not in methods:
        problems.append(f"no detection via {m}")
if not out["sim_page_banner_present"]:
    problems.append("lure-sim page banner missing")
for b in ["s1", "s2", "s3", "s4", "s5", "s6"]:
    if not out["sim_clipboard_after_click"][b].startswith(WARN):
        problems.append(f"lure-sim {b} was not blocked")
if out["sim_clipboard_after_click"]["s7"] != out["sim_control_expected"]:
    problems.append("lure-sim benign control was altered")
if out["pageerrors"]:
    problems.append("page errors: " + "; ".join(out["pageerrors"]))

print("\nE2E " + ("PASSED" if not problems else "FAILED: " + "; ".join(problems)))
sys.exit(1 if problems else 0)
