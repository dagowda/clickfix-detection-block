/* Node runner: node test/run-tests.js  (exit code 1 on failure) */
'use strict';
const path = require('path');
const fs = require('fs');
const D = require(path.join(__dirname, '..', 'src', 'detector.js'));
const runEngineTests = require(path.join(__dirname, 'engine-tests.js'));
const rules = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'rules.json'), 'utf8'));
const res = runEngineTests(D, rules);
console.log(res.lines.join('\n'));
console.log(res.failed ? `\nFAILED: ${res.failed} of ${res.total}` : `\nPASSED: ${res.total} tests`);
process.exit(res.failed ? 1 : 0);
