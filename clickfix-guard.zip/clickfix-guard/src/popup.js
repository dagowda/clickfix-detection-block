'use strict';

function send(msg) {
  return new Promise((resolve) => chrome.runtime.sendMessage(msg, (r) => resolve(chrome.runtime.lastError ? null : r)));
}
function hostOf(u) { try { return new URL(u).hostname; } catch (e) { return u || '(unknown)'; } }
function ago(iso) {
  const s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return Math.round(s) + 's ago';
  if (s < 3600) return Math.round(s / 60) + 'm ago';
  if (s < 86400) return Math.round(s / 3600) + 'h ago';
  return Math.round(s / 86400) + 'd ago';
}
function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}

let current = [];

async function render() {
  const eff = await send({ type: 'getEffectiveConfig' });
  const modeEl = document.getElementById('mode');
  if (eff) {
    if (!eff.ruleCount) { modeEl.textContent = 'no rules loaded'; modeEl.className = 'pill norules'; }
    else { modeEl.textContent = eff.config.mode + ' | ' + eff.ruleCount + ' rules'; modeEl.className = 'pill ' + eff.config.mode; }
  }
  const r = await send({ type: 'getDetections' });
  current = (r && r.detections) || [];
  const list = document.getElementById('list');
  list.textContent = '';
  if (!current.length) { list.appendChild(el('div', 'empty', 'No ClickFix attempts recorded on this browser.')); return; }
  for (const d of current.slice(0, 100)) {
    const rec = el('div', 'rec');
    const top = el('div', 'top');
    top.appendChild(el('span', 'host', hostOf(d.tabUrl || d.frameUrl)));
    const kind = d.type === 'page' ? 'page' : (d.blocked ? 'block' : 'audit');
    top.appendChild(el('span', 'tag ' + kind, d.type === 'page' ? 'suspicious page' : (d.debugOnly ? 'debug' : (d.blocked ? 'blocked' : 'audit'))));
    top.appendChild(el('span', 'tag', 'score ' + d.score));
    top.appendChild(el('span', 'when', ago(d.ts)));
    rec.appendChild(top);
    rec.appendChild(el('div', 'sig', (d.method ? d.method + ' | ' : '') + (d.signals || []).join(', ')));
    if (d.sample) rec.appendChild(el('div', 'sample', d.sample));
    list.appendChild(rec);
  }
}

document.getElementById('options').addEventListener('click', () => chrome.runtime.openOptionsPage());
document.getElementById('clear').addEventListener('click', async () => { await send({ type: 'clearDetections' }); render(); });
document.getElementById('export').addEventListener('click', () => {
  const blob = new Blob([JSON.stringify(current, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'clickfix-guard-detections.json'; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});
render();
