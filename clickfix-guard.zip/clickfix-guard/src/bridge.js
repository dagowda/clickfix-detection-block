/* ClickFix Guard - bridge.js  (isolated world, document_start, all frames)
 *
 * Relays between the page hooks (inject.js) and the extension background:
 *   - fetches rules + config from background and hands them to inject.js
 *   - forwards detections to background
 *   - draws the in-page warning banner on request (top frame only)
 */
(() => {
  'use strict';
  const EVT_OUT = 'clickfix-guard:detect';
  const EVT_IN = 'clickfix-guard:config';

  chrome.runtime.sendMessage({ type: 'getConfig', url: location.href }, (resp) => {
    if (chrome.runtime.lastError || !resp) return;
    try {
      document.dispatchEvent(new CustomEvent(EVT_IN, { detail: JSON.stringify(resp) }));
    } catch (e) { /* ignore */ }
  });

  document.addEventListener(EVT_OUT, (e) => {
    let data;
    try { data = JSON.parse(e.detail); } catch (err) { return; }
    if (!data || typeof data !== 'object') return;
    data.frameUrl = location.href;
    data.isTopFrame = (window === window.top);
    try { chrome.runtime.sendMessage({ type: 'detection', data }); } catch (err) { /* ignore */ }
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === 'banner' && window === window.top) showBanner(msg);
  });

  let host = null;
  function showBanner(msg) {
    try {
      if (host) host.remove();
      host = document.createElement('clickfix-guard-banner');
      const root = host.attachShadow({ mode: 'closed' });
      const isBlock = msg.kind === 'block';
      const org = msg.orgName || 'IT Security';
      const style = document.createElement('style');
      style.textContent =
        '.b{position:fixed;top:0;left:0;right:0;z-index:2147483647;font:14px/1.45 system-ui,Segoe UI,Arial,sans-serif;' +
        'color:#fff;background:' + (isBlock ? '#b3261e' : '#8a5a00') + ';padding:12px 16px;display:flex;gap:14px;align-items:center;' +
        'box-shadow:0 2px 10px rgba(0,0,0,.35)}' +
        '.b strong{font-size:15px}.t{flex:1}.a{display:flex;gap:8px}' +
        'button,a{font:inherit;border:1px solid rgba(255,255,255,.7);background:rgba(255,255,255,.12);color:#fff;' +
        'padding:6px 12px;border-radius:6px;cursor:pointer;text-decoration:none}' +
        'button:hover,a:hover{background:rgba(255,255,255,.25)}';
      const wrap = document.createElement('div');
      wrap.className = 'b';
      const t = document.createElement('div');
      t.className = 't';
      const s = document.createElement('strong');
      s.textContent = isBlock
        ? 'ClickFix Guard blocked a malicious clipboard command.'
        : 'ClickFix Guard: this page looks like a ClickFix scam.';
      const p = document.createElement('div');
      p.textContent = isBlock
        ? 'This website tried to copy a hidden command to your clipboard. Nothing harmful was copied. Do not follow its instructions. Please report this page to ' + org + '.'
        : 'Legitimate websites never ask you to press Win+R, Ctrl+V, Enter or to paste a command into a terminal. Close this page and report it to ' + org + '.';
      t.appendChild(s); t.appendChild(p);
      const a = document.createElement('div');
      a.className = 'a';
      if (msg.helpUrl) {
        const link = document.createElement('a');
        link.href = msg.helpUrl; link.target = '_blank'; link.rel = 'noopener'; link.textContent = 'Report';
        a.appendChild(link);
      }
      const btn = document.createElement('button');
      btn.textContent = 'Dismiss';
      btn.addEventListener('click', () => { host.remove(); host = null; });
      a.appendChild(btn);
      wrap.appendChild(t); wrap.appendChild(a);
      root.appendChild(style); root.appendChild(wrap);
      (document.documentElement || document).appendChild(host);
    } catch (e) { /* ignore */ }
  }
})();
