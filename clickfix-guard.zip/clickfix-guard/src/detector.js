/* ClickFix Guard - detector.js
 *
 * Generic weighted-rules engine. No DOM, no browser APIs.
 * Loaded in the page's MAIN world (inject.js grabs it and deletes the global)
 * and by the unit tests.
 *
 * Rules are data (see rules.json). Each rule:
 *   { id, weight, pattern, flags?, scope: "clipboard" | "page", key?, lure? }
 * The engine compiles the patterns once with loadRules() and then:
 *   score(text, ctx)  -> { score, signals[] }                for a clipboard write
 *   pageScore(text)   -> { score, signals[], keyCombo, lure } for page text
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module && module.exports) module.exports = api;
  else root.__ClickFixDetector = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const VERSION = '1.0.0';
  const DEFAULT_THRESHOLD = 5;
  const DEFAULT_PAGE_THRESHOLD = 5;
  const DEFAULT_WARNING =
    'BLOCKED by {org}: the website you were on tried to copy a hidden command to your clipboard (ClickFix attack). ' +
    'Do not paste it anywhere. Please report the page to {org}.';

  let clipRules = [];
  let pageRules = [];
  let combos = [];

  function compile(rule) {
    try {
      const flags = String(rule.flags || 'i').replace(/g/g, ''); // never global: .test() must be stateless
      return {
        id: String(rule.id),
        w: Number(rule.weight) || 0,
        key: !!rule.key,
        lure: !!rule.lure,
        re: new RegExp(rule.pattern, flags)
      };
    } catch (e) {
      return null; // bad pattern: skip it rather than break the engine
    }
  }

  function loadRules(def) {
    def = def || {};
    const all = Array.isArray(def.rules) ? def.rules : [];
    clipRules = all.filter(r => r && (r.scope || 'clipboard') === 'clipboard').map(compile).filter(Boolean);
    pageRules = all.filter(r => r && r.scope === 'page').map(compile).filter(Boolean);
    // combos: extra weight when all listed signal ids fired together
    combos = (Array.isArray(def.combos) ? def.combos : [])
      .filter(c => c && Array.isArray(c.all) && c.all.length)
      .map(c => ({ id: String(c.id), w: Number(c.weight) || 0, all: c.all.map(String) }));
    return { clipboard: clipRules.length, page: pageRules.length, combos: combos.length };
  }

  // Undo the cheap tricks used to break naive string matching.
  function normalize(raw) {
    return String(raw)
      .replace(/[\u200B-\u200F\u2028\u2029\uFEFF\u00AD]/g, '') // zero-width chars, soft hyphen
      .replace(/\^/g, '')                                      // cmd.exe caret escaping
      .replace(/`/g, '')                                       // PowerShell backtick escaping
      .replace(/["']\s*\+\s*["']/g, '')                        // "ab"+"cd" string splitting
      .replace(/\s+/g, ' ');
  }

  function score(text, ctx) {
    ctx = ctx || {};
    const raw = text == null ? '' : String(text);
    const signals = [];
    let total = 0;
    if (!raw.trim()) return { score: 0, signals, length: 0 };

    const norm = normalize(raw);
    for (const r of clipRules) {
      if (r.re.test(norm)) { signals.push(r.id); total += r.w; }
    }
    // Long runs of whitespace push the real command out of view in a one-line input.
    if (/[ \t]{10,}|(?:\r?\n){3,}/.test(raw)) { signals.push('whitespace-padding'); total += 1; }

    for (const c of combos) {
      if (c.all.every(id => signals.includes(id))) { signals.push(c.id); total += c.w; }
    }
    // The page itself is telling the user to open Run / Terminal and paste.
    if (Number(ctx.pageScore) >= 3) { signals.push('page-context'); total += 2; }

    return { score: total, signals, length: raw.length };
  }

  function pageScore(text) {
    const t = String(text == null ? '' : text).replace(/\s+/g, ' ');
    const signals = [];
    let total = 0, key = false, lure = false;
    for (const r of pageRules) {
      if (r.re.test(t)) {
        signals.push(r.id); total += r.w;
        if (r.key) key = true;
        if (r.lure) lure = true;
      }
    }
    // Gate: a page only counts as a lure when it both names a key combo
    // (how to execute) AND gives a reason (captcha / fix / verification).
    // An ordinary IT help article has the first without the second.
    return { score: key && lure ? total : 0, signals, keyCombo: key, lure };
  }

  return { VERSION, DEFAULT_THRESHOLD, DEFAULT_PAGE_THRESHOLD, DEFAULT_WARNING, loadRules, normalize, score, pageScore };
});
