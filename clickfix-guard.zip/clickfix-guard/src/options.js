'use strict';

const FIELDS = ['mode', 'threshold', 'pageBannerThreshold', 'allowDomains', 'orgName', 'helpUrl', 'warningText', 'showOverlay', 'notify', 'logAll', 'reportUrl', 'reportToken', 'clientTag'];

function send(msg) {
  return new Promise((resolve) => chrome.runtime.sendMessage(msg, (r) => resolve(chrome.runtime.lastError ? null : r)));
}
function get(area, keys) {
  return new Promise((resolve) => chrome.storage[area].get(keys, (v) => resolve(chrome.runtime.lastError ? {} : (v || {}))));
}

async function load() {
  const eff = await send({ type: 'getEffectiveConfig' });
  const cfg = (eff && eff.config) || {};
  const managedKeys = cfg.managedKeys || [];
  for (const k of FIELDS) {
    const el = document.getElementById(k);
    if (!el) continue;
    const v = cfg[k];
    if (el.type === 'checkbox') el.checked = (k === 'logAll') ? v === true : v !== false;
    else if (k === 'allowDomains') el.value = Array.isArray(v) ? v.join('\n') : (v || '');
    else el.value = v == null ? '' : v;
    if (managedKeys.includes(k)) {
      el.disabled = true;
      el.closest('label, div, fieldset') && (el.title = 'Set by enterprise policy');
    }
  }
  const m = document.getElementById('managed');
  if (managedKeys.length) {
    m.hidden = false;
    m.textContent = 'Locked by enterprise policy: ' + managedKeys.join(', ');
  }
  const local = await get('local', 'extraRules');
  document.getElementById('extraRules').value = local.extraRules
    ? (typeof local.extraRules === 'string' ? local.extraRules : JSON.stringify(local.extraRules, null, 2))
    : '';
  if (managedKeys.includes('extraRules')) document.getElementById('extraRules').disabled = true;
  document.getElementById('rulestat').textContent = eff
    ? 'Rules in effect: ' + eff.ruleCount + ' rules, ' + eff.comboCount + ' combos.'
    : '';
}

document.getElementById('f').addEventListener('submit', async (e) => {
  e.preventDefault();
  const status = document.getElementById('status');
  const options = {};
  for (const k of FIELDS) {
    const el = document.getElementById(k);
    if (!el || el.disabled) continue;
    if (el.type === 'checkbox') options[k] = el.checked;
    else if (el.type === 'number') options[k] = Number(el.value) || undefined;
    else if (k === 'allowDomains') options[k] = el.value.split(/[\s,;]+/).map(s => s.trim()).filter(Boolean);
    else options[k] = el.value.trim();
  }
  let extraRules = document.getElementById('extraRules').value.trim();
  if (extraRules) {
    try { extraRules = JSON.parse(extraRules); }
    catch (err) { status.style.color = '#b3261e'; status.textContent = 'Extra rules is not valid JSON: ' + err.message; return; }
  } else {
    extraRules = null;
  }
  chrome.storage.local.set({ options, extraRules }, () => {
    status.style.color = '#1e7e34';
    status.textContent = chrome.runtime.lastError ? 'Save failed' : 'Saved';
    setTimeout(() => { status.textContent = ''; }, 2500);
    load();
  });
});

document.getElementById('flush').addEventListener('click', async () => {
  await send({ type: 'flushQueue' });
  const status = document.getElementById('status');
  status.textContent = 'Retry triggered';
  setTimeout(() => { status.textContent = ''; }, 2500);
});

load();
