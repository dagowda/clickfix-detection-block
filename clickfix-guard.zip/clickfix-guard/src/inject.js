/* ClickFix Guard - inject.js  (MAIN world, document_start, all frames)
 *
 * Wraps the four ways a page can put text on the clipboard:
 *   navigator.clipboard.writeText / .write
 *   document.execCommand('copy' | 'cut')
 *   DataTransfer.prototype.setData   (copy-event handlers)
 * Scores the text; on a hit in block mode, the warning text is written instead.
 * Talks to bridge.js (isolated world) through DOM CustomEvents.
 */
(() => {
  'use strict';
  const D = globalThis.__ClickFixDetector;
  try { delete globalThis.__ClickFixDetector; } catch (e) { /* ignore */ }
  if (!D) return;

  const EVT_OUT = 'clickfix-guard:detect';   // inject -> bridge
  const EVT_IN = 'clickfix-guard:config';    // bridge -> inject (rules + settings)

  const cfg = {
    mode: 'block',
    threshold: D.DEFAULT_THRESHOLD,
    pageBannerThreshold: D.DEFAULT_PAGE_THRESHOLD,
    allowed: false,
    logAll: false,
    orgName: 'IT Security',
    warningText: D.DEFAULT_WARNING
  };
  let configApplied = false;
  let rulesLoaded = false;

  // Only the first config message is honoured. The bridge sends it as soon as
  // the background answers; a page script would have to win that race to spoof it.
  document.addEventListener(EVT_IN, (e) => {
    if (configApplied) return;
    configApplied = true;
    try {
      const msg = JSON.parse(e.detail);
      if (msg.rules) { D.loadRules(msg.rules); rulesLoaded = true; }
      if (msg.config) Object.assign(cfg, msg.config);
    } catch (err) { /* ignore malformed */ }
    scheduleScan(); // rules may have arrived after the first page scan
  }, { capture: true });

  function emit(payload) {
    try {
      document.dispatchEvent(new CustomEvent(EVT_OUT, { detail: JSON.stringify(payload) }));
    } catch (e) { /* ignore */ }
  }
  function warning() {
    return String(cfg.warningText || D.DEFAULT_WARNING).replace(/\{org\}/g, cfg.orgName || 'IT Security');
  }

  // ---- page-context scoring -------------------------------------------------
  let pageScore = 0, pageSignals = [], pageReported = false, scans = 0, scanTimer = null, lastScan = 0;

  function scanPage() {
    scanTimer = null; lastScan = Date.now(); scans++;
    try {
      const body = document.body;
      if (!body) return;
      const text = (body.innerText || body.textContent || '').slice(0, 300000);
      const r = D.pageScore(text);
      pageScore = r.score; pageSignals = r.signals;
      if (!pageReported && pageScore >= cfg.pageBannerThreshold) {
        pageReported = true;
        emit({ type: 'page', score: pageScore, signals: pageSignals, url: location.href });
      }
    } catch (e) { /* ignore */ }
  }
  function scheduleScan() {
    if (scanTimer || scans > 40) return; // cap work on very chatty SPAs
    const wait = Math.max(0, 1500 - (Date.now() - lastScan));
    scanTimer = setTimeout(scanPage, wait);
  }
  function startScanning() {
    scheduleScan();
    setTimeout(scheduleScan, 2500); // catch content rendered after load
    try {
      new MutationObserver(scheduleScan).observe(document.documentElement, { childList: true, subtree: true, characterData: true });
    } catch (e) { /* ignore */ }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', startScanning, { once: true });
  else startScanning();

  // ---- clipboard evaluation -------------------------------------------------
  function evaluate(text, method) {
    if (typeof text !== 'string' || text.length < 4) return null;
    const r = D.score(text, { pageScore });
    const hit = r.score >= cfg.threshold;
    if (!hit && !cfg.logAll) return null;
    const block = hit && cfg.mode === 'block' && !cfg.allowed;
    emit({
      type: 'clipboard',
      method,
      score: r.score,
      signals: r.signals,
      sample: text.slice(0, 200),
      length: text.length,
      blocked: block,
      debugOnly: !hit,
      rulesLoaded,
      url: location.href
    });
    return hit ? { block, result: r } : null;
  }

  function selectedText(doc) {
    try {
      const el = doc.activeElement;
      if (el && (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') && typeof el.value === 'string') {
        const s = el.selectionStart, e = el.selectionEnd;
        return (s != null && e != null && e > s) ? el.value.slice(s, e) : el.value;
      }
      const sel = doc.getSelection && doc.getSelection();
      return sel ? sel.toString() : '';
    } catch (e) { return ''; }
  }

  function textFromHtml(html) {
    try { return String(html).replace(/<[^>]*>/g, ' '); } catch (e) { return ''; }
  }

  // ---- hooks ----------------------------------------------------------------
  const origWriteText = Clipboard.prototype.writeText;
  const origWrite = Clipboard.prototype.write;
  const origExec = Document.prototype.execCommand;
  const origSetData = DataTransfer.prototype.setData;

  function define(obj, name, fn, orig) {
    try {
      Object.defineProperty(fn, 'name', { value: name });
      Object.defineProperty(fn, 'length', { value: orig.length });
      Object.defineProperty(obj, name, { value: fn, writable: true, configurable: true });
    } catch (e) { obj[name] = fn; }
  }

  define(Clipboard.prototype, 'writeText', function writeText(text) {
    const v = evaluate(String(text), 'clipboard.writeText');
    if (v && v.block) return origWriteText.call(this, warning());
    return origWriteText.call(this, text);
  }, origWriteText);

  define(Clipboard.prototype, 'write', async function write(items) {
    try {
      for (const item of Array.from(items || [])) {
        if (!item || !item.types) continue;
        for (const type of item.types) {
          if (type !== 'text/plain' && type !== 'text/html') continue;
          const blob = await item.getType(type);
          let text = await blob.text();
          if (type === 'text/html') text = textFromHtml(text);
          const v = evaluate(text, 'clipboard.write[' + type + ']');
          if (v && v.block) return origWriteText.call(this, warning());
        }
      }
    } catch (e) { /* fall through to the original */ }
    return origWrite.call(this, items);
  }, origWrite);

  define(Document.prototype, 'execCommand', function execCommand(cmd) {
    const args = Array.prototype.slice.call(arguments);
    if (typeof cmd === 'string' && /^(copy|cut)$/i.test(cmd)) {
      const v = evaluate(selectedText(this), 'execCommand(' + cmd + ')');
      if (v && v.block) {
        const win = this.defaultView || globalThis;
        const evName = cmd.toLowerCase();
        // Capture-phase listener on window runs before any page handler, so we
        // own the clipboard payload for this one event.
        const handler = (ev) => {
          ev.stopImmediatePropagation();
          ev.preventDefault();
          if (ev.clipboardData) origSetData.call(ev.clipboardData, 'text/plain', warning());
        };
        win.addEventListener(evName, handler, { capture: true, once: true });
        try { return origExec.apply(this, args); }
        finally { win.removeEventListener(evName, handler, { capture: true }); }
      }
    }
    return origExec.apply(this, args);
  }, origExec);

  define(DataTransfer.prototype, 'setData', function setData(format, data) {
    if (typeof data === 'string' && /text/i.test(String(format))) {
      const text = /html/i.test(String(format)) ? textFromHtml(data) : data;
      const v = evaluate(text, 'clipboardData.setData');
      if (v && v.block) return origSetData.call(this, format, warning());
    }
    return origSetData.call(this, format, data);
  }, origSetData);
})();
