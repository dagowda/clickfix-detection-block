/* ClickFix Guard - background.js (MV3 service worker)
 *
 * - Serves rules + effective config to content scripts
 * - Stores detections locally (last 500), updates the badge, notifies the user
 * - POSTs each detection to the configured SIEM / webhook endpoint
 * - Asks the tab's top frame to draw the warning banner
 */
'use strict';

const VERSION = chrome.runtime.getManifest().version;
const MAX_RECORDS = 500;

const DEFAULTS = {
  mode: 'block',
  threshold: 5,
  pageBannerThreshold: 5,
  allowDomains: [],
  reportUrl: '',
  reportToken: '',
  clientTag: '',
  orgName: 'IT Security',
  warningText: '',
  showOverlay: true,
  notify: true,
  helpUrl: '',
  logAll: false
};

function storageGet(area, keys) {
  return new Promise((resolve) => {
    try { chrome.storage[area].get(keys, (v) => resolve(chrome.runtime.lastError ? {} : (v || {}))); }
    catch (e) { resolve({}); }
  });
}
function storageSet(area, obj) {
  return new Promise((resolve) => {
    try { chrome.storage[area].set(obj, () => resolve(!chrome.runtime.lastError)); }
    catch (e) { resolve(false); }
  });
}

// Precedence: defaults < local options (options page) < managed policy (GPO/Intune).
async function getConfig() {
  const local = (await storageGet('local', 'options')).options || {};
  const managed = await storageGet('managed', null);
  const cfg = Object.assign({}, DEFAULTS, local);
  for (const k of Object.keys(DEFAULTS)) {
    if (managed[k] !== undefined && managed[k] !== null) cfg[k] = managed[k];
  }
  if (typeof cfg.allowDomains === 'string') {
    cfg.allowDomains = cfg.allowDomains.split(/[\s,;]+/).filter(Boolean);
  }
  cfg.managedKeys = Object.keys(managed);
  return cfg;
}

let rulesCache = null;
async function getRules() {
  if (rulesCache) return rulesCache;
  const base = await fetch(chrome.runtime.getURL('rules.json')).then(r => r.json()).catch(() => ({ rules: [], combos: [] }));
  // Optional extra rules supplied by policy or the options page (same schema).
  const local = (await storageGet('local', 'extraRules')).extraRules;
  const managed = (await storageGet('managed', 'extraRules')).extraRules;
  const extra = [managed, local].map(parseRules).filter(Boolean);
  const merged = {
    rules: [].concat(base.rules || [], ...extra.map(e => e.rules || [])),
    combos: [].concat(base.combos || [], ...extra.map(e => e.combos || []))
  };
  rulesCache = merged;
  return merged;
}
function parseRules(v) {
  if (!v) return null;
  if (typeof v === 'object') return v;
  try { return JSON.parse(v); } catch (e) { return null; }
}
chrome.storage.onChanged.addListener(() => { rulesCache = null; });

function hostOf(url) {
  try { return new URL(url).hostname.toLowerCase(); } catch (e) { return ''; }
}
function hostAllowed(url, allowDomains) {
  const h = hostOf(url);
  if (!h) return false;
  return (allowDomains || []).some((d) => {
    d = String(d || '').trim().toLowerCase().replace(/^\*\./, '').replace(/^\./, '');
    return d && (h === d || h.endsWith('.' + d));
  });
}

async function sha256Hex(text) {
  try {
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
    return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
  } catch (e) { return ''; }
}

async function handleDetection(data, sender) {
  const cfg = await getConfig();
  const tab = sender.tab || {};
  const rec = {
    id: Date.now().toString(36) + Math.random().toString(36).slice(2, 8),
    ts: new Date().toISOString(),
    version: VERSION,
    type: data.type,                       // 'clipboard' | 'page'
    method: data.method || null,
    score: data.score,
    signals: data.signals || [],
    blocked: !!data.blocked,
    debugOnly: !!data.debugOnly,
    sample: typeof data.sample === 'string' ? data.sample.slice(0, 200) : null,
    sampleHash: data.sample ? await sha256Hex(data.sample) : null,
    payloadLength: data.length || null,
    rulesLoaded: data.rulesLoaded !== false,
    frameUrl: data.frameUrl || null,
    isTopFrame: data.isTopFrame !== false,
    tabUrl: tab.url || null,
    tabTitle: tab.title || null,
    tabId: tab.id != null ? tab.id : null,
    frameId: sender.frameId != null ? sender.frameId : null,
    mode: cfg.mode,
    clientTag: cfg.clientTag || null,
    userAgent: navigator.userAgent
  };

  // 1. persist
  const store = await storageGet('local', ['detections', 'unread']);
  const list = Array.isArray(store.detections) ? store.detections : [];
  list.unshift(rec);
  if (list.length > MAX_RECORDS) list.length = MAX_RECORDS;
  const unread = (Number(store.unread) || 0) + 1;
  await storageSet('local', { detections: list, unread });

  // 2. badge
  try {
    await chrome.action.setBadgeBackgroundColor({ color: '#b3261e' });
    await chrome.action.setBadgeText({ text: unread > 99 ? '99+' : String(unread) });
  } catch (e) { /* ignore */ }

  // 3. notification (blocks only, to avoid noise)
  if (cfg.notify && rec.type === 'clipboard' && rec.blocked) {
    try {
      chrome.notifications.create(rec.id, {
        type: 'basic',
        iconUrl: chrome.runtime.getURL('icons/icon128.png'),
        title: 'ClickFix Guard blocked a malicious command',
        message: (hostOf(rec.tabUrl || rec.frameUrl) || 'A web page') +
          ' tried to copy a hidden command to your clipboard. Nothing harmful was copied. Please report it to ' +
          (cfg.orgName || 'IT Security') + '.',
        priority: 2
      });
    } catch (e) { /* ignore */ }
  }

  // 4. banner in the top frame of that tab (not for debug-only records)
  if (cfg.showOverlay && rec.tabId != null && !rec.debugOnly) {
    try {
      chrome.tabs.sendMessage(rec.tabId, {
        type: 'banner',
        kind: rec.type === 'clipboard' && rec.blocked ? 'block' : 'page',
        orgName: cfg.orgName,
        helpUrl: cfg.helpUrl || ''
      }, { frameId: 0 }, () => void chrome.runtime.lastError);
    } catch (e) { /* ignore */ }
  }

  // 5. beacon
  await beacon(cfg, rec);
}

async function beacon(cfg, rec) {
  if (!cfg.reportUrl || !/^https?:\/\//i.test(cfg.reportUrl)) return;
  const headers = { 'Content-Type': 'application/json' };
  if (cfg.reportToken) headers.Authorization = 'Bearer ' + cfg.reportToken;
  const body = JSON.stringify({ source: 'clickfix-guard', event: rec });
  try {
    await fetch(cfg.reportUrl, { method: 'POST', headers, body, keepalive: true });
  } catch (e) {
    // Queue for retry so a flaky SIEM endpoint does not lose events.
    const q = (await storageGet('local', 'beaconQueue')).beaconQueue || [];
    q.push({ body, tries: 1 });
    if (q.length > 200) q.splice(0, q.length - 200);
    await storageSet('local', { beaconQueue: q });
  }
}

async function flushQueue() {
  const cfg = await getConfig();
  if (!cfg.reportUrl) return;
  const q = (await storageGet('local', 'beaconQueue')).beaconQueue || [];
  if (!q.length) return;
  const headers = { 'Content-Type': 'application/json' };
  if (cfg.reportToken) headers.Authorization = 'Bearer ' + cfg.reportToken;
  const remaining = [];
  for (const item of q) {
    try { await fetch(cfg.reportUrl, { method: 'POST', headers, body: item.body }); }
    catch (e) { if (item.tries < 20) remaining.push({ body: item.body, tries: item.tries + 1 }); }
  }
  await storageSet('local', { beaconQueue: remaining });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg !== 'object') return false;

  if (msg.type === 'getConfig') {
    Promise.all([getConfig(), getRules()]).then(([cfg, rules]) => {
      sendResponse({
        config: {
          mode: cfg.mode,
          threshold: Number(cfg.threshold) || DEFAULTS.threshold,
          pageBannerThreshold: Number(cfg.pageBannerThreshold) || DEFAULTS.pageBannerThreshold,
          allowed: hostAllowed(msg.url, cfg.allowDomains),
          orgName: cfg.orgName,
          warningText: cfg.warningText || undefined,
          logAll: !!cfg.logAll
        },
        rules
      });
    }).catch(() => sendResponse(null));
    return true;
  }

  if (msg.type === 'detection') {
    handleDetection(msg.data || {}, sender).then(() => sendResponse({ ok: true })).catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (msg.type === 'getDetections') {
    storageGet('local', ['detections']).then(async (s) => {
      await storageSet('local', { unread: 0 });
      try { await chrome.action.setBadgeText({ text: '' }); } catch (e) { /* ignore */ }
      sendResponse({ detections: s.detections || [] });
    });
    return true;
  }

  if (msg.type === 'clearDetections') {
    storageSet('local', { detections: [], unread: 0 }).then(async () => {
      try { await chrome.action.setBadgeText({ text: '' }); } catch (e) { /* ignore */ }
      sendResponse({ ok: true });
    });
    return true;
  }

  if (msg.type === 'getEffectiveConfig') {
    Promise.all([getConfig(), getRules()]).then(([cfg, rules]) => {
      sendResponse({ config: cfg, ruleCount: (rules.rules || []).length, comboCount: (rules.combos || []).length });
    });
    return true;
  }

  if (msg.type === 'flushQueue') {
    flushQueue().then(() => sendResponse({ ok: true }));
    return true;
  }
  return false;
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms && chrome.alarms.create && chrome.alarms.create('flush', { periodInMinutes: 5 });
});
if (chrome.alarms && chrome.alarms.onAlarm) {
  chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'flush') flushQueue(); });
}
