# Generates rules.json:  python tools/genrules.py   (run from the extension root)
# Edit the rule list here rather than hand-escaping regexes in JSON. Patterns are Python raw strings; json.dump doubles
# the backslashes. Text is pre-normalised by detector.js (carets, backticks, zero-width
# chars and "a"+"b" splits removed; whitespace collapsed) before these run.
import json, sys

BS = chr(92)
def uesc(cp):  # JS regex \uXXXX escape built programmatically (tooling mangles typed ones)
    return BS + 'u' + format(cp, '04X')

# PowerShell accepts -, /, en dash and em dash as parameter prefixes
D = '[-/' + uesc(0x2013) + uesc(0x2014) + ']'
GLYPHS = ''.join(uesc(c) for c in (0x2713, 0x2714, 0x2705, 0x2611))  # check marks
WINKEY = uesc(0x229E)
CMDKEY = uesc(0x2318)

def abbrev(word, min_len):
    """PowerShell accepts any unambiguous prefix: windowstyle -> w, wi, win, ..."""
    nested = ''
    for ch in reversed(word[min_len:]):
        nested = '(?:' + ch + nested + ')?'
    return word[:min_len] + nested

rules = [
  # ---- self-test (keep) ---------------------------------------------------
  {"id": "selftest-clipboard", "weight": 10, "scope": "clipboard", "pattern": "CLICKFIX-GUARD-SELFTEST-CLIPBOARD"},
  {"id": "selftest-page-key", "weight": 3, "scope": "page", "key": True, "pattern": "CLICKFIX-GUARD-SELFTEST-PAGE-KEY"},
  {"id": "selftest-page-lure", "weight": 3, "scope": "page", "lure": True, "pattern": "CLICKFIX-GUARD-SELFTEST-PAGE-LURE"},

  # ---- living-off-the-land binaries --------------------------------------
  {"id": "lolbin-powershell", "weight": 2,
   "pattern": r"\b(?:powershell|pwsh)(?:\.exe)?\b"},
  {"id": "lolbin-mshta", "weight": 3,
   "pattern": r"\bmshta(?:\.exe)?\b"},
  {"id": "lolbin-rare", "weight": 2,
   "pattern": r"\b(?:rundll32|regsvr32|certutil|bitsadmin|wscript|cscript|forfiles|conhost|finger|cmstp|installutil|regasm|regsvcs|msbuild|odbcconf|pcalua|scriptrunner|syncappvpublishingserver|msxsl|wmic|cmdl32|ieexec|presentationhost|msdt)(?:\.exe|\.vbs)?\b"},
  {"id": "lolbin-cmd", "weight": 1,
   "pattern": r"\bcmd(?:\.exe)?\s+/[ckr]\b"},
  {"id": "lolbin-macos", "weight": 2,
   "pattern": r"\b(?:osascript|xattr|launchctl|dscl)\b|\bsecurity\s+(?:find-generic-password|dump-keychain)\b"},
  {"id": "lolbin-script-host", "weight": 1,
   "pattern": r"\b(?:python[0-9.]*|perl|ruby|node)(?:\.exe)?\s+-[ce]\b"},

  # ---- remote location ----------------------------------------------------
  {"id": "remote-url", "weight": 2,
   "pattern": r"\b(?:https?|ftp)://"},
  {"id": "remote-unc", "weight": 2,
   "pattern": r"\\\\[a-z0-9.-]+(?:@(?:ssl|\d+))*\\[^\s]"},
  {"id": "remote-bare-ip", "weight": 2,   # public IPv4 only: loopback, 0/8 and RFC1918 excluded
   "pattern": r"(?<![\d.])(?!(?:10|127|0)\.|192\.168\.|172\.(?:1[6-9]|2\d|3[01])\.)(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)(?![\d]|\.\d)"},

  # ---- hidden window / policy bypass -------------------------------------
  {"id": "hide-window", "weight": 2,
   "pattern": r"(?:^|\s)" + D + abbrev("windowstyle", 1) + r"\s+(?:" + abbrev("hidden", 1) + r"|1|" + abbrev("minimized", 3) + r")\b|\bconhost(?:\.exe)?\s+--headless\b|\bstart\s+(?:\"[^\"]*\"\s+)?/min\b|\bvbhide\b"},
  {"id": "policy-bypass", "weight": 1,
   "pattern": r"(?:^|\s)" + D + r"e[a-z]*\s+(?:bypass|unrestricted)\b|(?:^|\s)" + D + r"no(?:p|ni)[a-z]*\b"},

  # ---- encoded command ----------------------------------------------------
  {"id": "encoded-command", "weight": 3,
   "pattern": r"(?:^|\s)" + D + r"e(?:c|n[a-z]*)?\s+[a-z0-9+/]{40,}={0,2}(?=$|[\s\"';|)])"},
  {"id": "long-base64-blob", "weight": 1,
   "pattern": r"[a-z0-9+/]{120,}={0,2}"},

  # ---- download / execute -------------------------------------------------
  {"id": "download-cmdlet", "weight": 1,
   "pattern": r"\b(?:iwr|irm|invoke-webrequest|invoke-restmethod|start-bitstransfer|wget|curl(?:\.exe)?|downloadstring|downloadfile|downloaddata|net\.webclient|webclient|system\.net\.http\.httpclient|msxml2\.xmlhttp|winhttp\.winhttprequest)\b"},
  {"id": "execute-cmdlet", "weight": 2,
   "pattern": r"\b(?:iex|invoke-expression)\b|\[scriptblock\]::create|\.invokescript\(|(?:^|[\s;(|])[.&]\s*\(\s*(?:\$|\[|gcm\b|get-command\b)|\bgcm\s+\S*\*|\binvoke-command\s+-scriptblock"},
  {"id": "pipe-to-shell", "weight": 1,
   "pattern": r"\|\s*(?:/(?:usr/)?bin/)?(?:ba|z|da|k)?sh\b|\|\s*(?:powershell|pwsh|cmd|python[0-9.]*|perl|ruby|osascript)(?:\.exe)?\b"},
  {"id": "shell-subst-download", "weight": 1,
   "pattern": r"\b(?:ba|z)?sh\s+-c\s+[\"']?\$\(\s*(?:curl|wget)\b"},
  {"id": "write-then-run-temp", "weight": 1,
   "pattern": r"%(?:temp|tmp|appdata|localappdata|public|programdata)%|\$env:(?:temp|tmp|appdata|localappdata|public|programdata)\b|\\users\\public\\|\\appdata\\(?:local|roaming)\\|(?:^|[\s\"'])/(?:private/)?tmp/|\[io\.path\]::gettemppath"},

  # ---- remote installer / cert-tool / fetch tricks ------------------------
  {"id": "msiexec-remote", "weight": 3,
   "pattern": r"\bmsiexec(?:\.exe)?\b.{0,40}?[\s\"']/(?:i|package|y)\s*[\"']?(?:https?://|\\\\)"},
  {"id": "certutil-fetch", "weight": 3,
   "pattern": r"\bcertutil(?:\.exe)?\b.{0,80}?[-/](?:urlcache|verifyctl|decode|decodehex)\b"},
  {"id": "bitsadmin-transfer", "weight": 2,
   "pattern": r"\bbitsadmin(?:\.exe)?\b.{0,80}?/(?:transfer|addfile|create)\b"},
  {"id": "regsvr32-scriptlet", "weight": 3,
   "pattern": r"\bregsvr32(?:\.exe)?\b.{0,80}?(?:/i:|scrobj)"},
  {"id": "rundll32-script", "weight": 3,
   "pattern": r"\brundll32(?:\.exe)?\b.{0,120}?(?:javascript:|vbscript:|mshtml|url\.dll|ieframe\.dll|shell32\.dll\s*,\s*shellexec_rundll|davclnt\.dll|\\\\)"},
  {"id": "finger-fetch", "weight": 3,
   "pattern": r"\bfinger(?:\.exe)?\s+\S+@\S+"},
  {"id": "nslookup-stager", "weight": 3,
   "pattern": r"\bnslookup\b[^|]{0,120}\|"},
  {"id": "wmic-process-create", "weight": 2,
   "pattern": r"\bwmic\b.{0,60}?\bprocess\s+call\s+create\b"},
  {"id": "defender-tamper", "weight": 3,
   "pattern": r"\b(?:add|set)-mppreference\b.{0,80}?" + D + r"(?:exclusion|disable)"},
  {"id": "macos-quarantine-strip", "weight": 3,
   "pattern": r"\bxattr\s+-(?:c|r?d)\b|com\.apple\.quarantine"},
  {"id": "macos-download-exec", "weight": 2,
   "pattern": r"\b(?:curl|wget)\b.{0,200}?(?:&&|;)\s*(?:chmod\s+\+x|open\s|\./|/tmp/)"},

  # ---- obfuscation helpers ------------------------------------------------
  {"id": "obf-char-cast", "weight": 2,
   "pattern": r"\[char\]\s*\(?\s*(?:0x[0-9a-f]+|\d+)|\[char\[\]\]"},
  {"id": "obf-reverse-join", "weight": 2,
   "pattern": r"\[array\]::reverse|-join\s*\(?\s*\[char|\[regex\]::matches\([^)]*righttoleft|\[string\]::join\(\s*[\"']{2}"},
  {"id": "obf-string-ops", "weight": 1,
   "pattern": r"(?:^|\s)-(?:join|replace|split)\b|\.replace\(|\s-f\s+[\"']"},
  {"id": "obf-base64-decode", "weight": 2,
   "pattern": r"frombase64string|\[(?:system\.)?text\.encoding\]::|\bbase64\s+(?:-d|--decode|-D)\b|\batob\s*\(|\bopenssl\s+(?:base64|enc)\s+-d\b"},
  {"id": "obf-env-slice", "weight": 2,
   "pattern": r"\$env:comspec\[|\$pshome\[|\$shellid\[|\$verbosepreference\.tostring\(\)|\(\s*\$env:public\s*\)\["},
  {"id": "obf-wildcard-exe", "weight": 3,
   "pattern": r"[a-z]:\\(?:[^\\\s\"']*\\)*[^\\\s\"']*\*[^\\\s\"']*\.exe"},
  {"id": "base64-pipe-shell", "weight": 3,
   "pattern": r"\bbase64\s+(?:-d|--decode|-D)\b[^|]{0,40}\|\s*(?:/(?:usr/)?bin/)?(?:ba|z)?sh\b"},

  # ---- decoy comment: the single strongest ClickFix tell -------------------
  {"id": "decoy-comment", "weight": 3,
   "pattern": r"(?:^|[\s;&|\"'])(?:#|::|rem\s|//|<#).{0,160}?(?:not\s+a\s+robot|i\s*'?\s*a?m\s+(?:a\s+)?human|human\s+(?:verification|check)|captcha|cloudflare|ray[\s-]*id|verif(?:y|ied|ication)|security\s+check|validation|authenticat|confirm|\bfix\b|turnstile|[" + GLYPHS + r"])"},
  {"id": "decoy-filefix-path", "weight": 3,
   "pattern": r"#\s*[\"']?[a-z]:\\[^#]{0,200}?\.(?:docx?|pdf|xlsx?|pptx?|txt|csv)\b"},

  # ---- page rules ---------------------------------------------------------
  {"id": "page-key-run", "weight": 3, "scope": "page", "key": True,
   "pattern": r"(?:\bwin(?:dows)?(?:\s+logo)?(?:\s+key)?|" + WINKEY + r")\s*(?:\+|and|&)\s*(?:the\s+)?(?:letter\s+)?[\"']?r\b|\bopen\s+(?:the\s+)?run\s+(?:dialog|box|window|prompt)|\brun\s+dialog\b"},
  {"id": "page-key-terminal", "weight": 2, "scope": "page", "key": True,
   "pattern": r"\bwin(?:dows)?(?:\s+key)?\s*\+\s*[\"']?x\b|\b(?:windows\s+)?terminal\s*\(admin\)|\bpowershell\s*\(admin\)|\bopen\s+(?:the\s+)?(?:terminal|command\s+prompt|powershell)\b|(?:\b(?:cmd|command)|" + CMDKEY + r")\s*\+\s*space\b|\bwin(?:dows)?\s*\+\s*[\"']?e\b|\b(?:ctrl|control)\s*\+\s*l\b|\bfile\s+explorer\s+address\s+bar\b"},
  {"id": "page-key-paste", "weight": 1, "scope": "page", "key": True,
   "pattern": r"(?:\b(?:ctrl|control|cmd|command)|" + CMDKEY + r")\s*\+?\s*[\"']?v\b|\bpaste\s+(?:it|the\s+(?:code|command|text|verification|file\s+path|path))\b|\bright[\s-]click\s+to\s+paste\b"},
  {"id": "page-lure-captcha", "weight": 3, "scope": "page", "lure": True,
   "pattern": r"\bi\s*'?\s*a?m\s+not\s+a\s+robot\b|\bverify\s+(?:that\s+)?you(?:'re|\s+are)\s+(?:a\s+)?human\b|\bhuman\s+verification\b|\bre?captcha\b|\bverification\s+(?:steps?|id|code)\b|\bray\s*id\b|\bsecurity\s+check\b|\bcomplete\s+(?:the\s+)?verification\b"},
  {"id": "page-lure-fix", "weight": 2, "scope": "page", "lure": True,
   "pattern": r"\b(?:fix\s+(?:it|this|the\s+(?:error|issue|problem))|how\s+to\s+fix)\b|\b(?:browser|chrome|edge|driver|font|plugin|extension|camera|microphone|document|word)\s+(?:needs?\s+(?:an?\s+)?update|update\s+required|is\s+(?:out\s+of\s+date|outdated)|error)\b|\bfailed\s+to\s+(?:load|display|connect|render)\b|\bfont\s+(?:was\s+)?not\s+found\b|\broot\s+certificate\b|\bto\s+(?:view|open|access)\s+(?:the|this)\s+(?:document|file|shared\s+file)\b"},
  {"id": "page-step-enter", "weight": 1, "scope": "page",
   "pattern": r"\b(?:press|hit|tap)\s+(?:the\s+)?(?:enter|return)\b"},
  {"id": "page-step-numbered", "weight": 1, "scope": "page",
   "pattern": r"\bstep\s*[1-3]\b"},
  {"id": "page-copied", "weight": 1, "scope": "page",
   "pattern": r"\b(?:code|command|text)\s+(?:has\s+been\s+|was\s+)?copied\b|\bcopied\s+to\s+(?:your\s+)?clipboard\b"},
]

combos = [
  {"id": "combo-mshta-remote", "weight": 2, "all": ["lolbin-mshta", "remote-url"]},
  {"id": "combo-powershell-remote", "weight": 1, "all": ["lolbin-powershell", "remote-url"]},
  {"id": "combo-rare-remote", "weight": 1, "all": ["lolbin-rare", "remote-url"]},
  {"id": "combo-download-cradle", "weight": 1, "all": ["download-cmdlet", "execute-cmdlet"]},
  {"id": "combo-hidden-powershell", "weight": 1, "all": ["lolbin-powershell", "hide-window"]},
]

comment = [
  "ClickFix Guard rule set. Loaded by background.js and handed to the page hooks.",
  "Each rule: { id, weight, pattern (JS RegExp source), flags (default 'i'), scope ('clipboard' default | 'page'), key, lure }.",
  "clipboard rules score text a page writes to the clipboard. A write is blocked when the sum of weights >= threshold (default 5).",
  "page rules score the visible page text. key=true marks 'how to execute' instructions (a key combo); lure=true marks the pretext",
  "(captcha / fix / verification). Page score only counts when at least one key rule AND one lure rule fire.",
  "combos add weight when every listed signal id fired on the same text.",
  "Built-in signals the engine adds itself: whitespace-padding (+1) and page-context (+2 when the page score is >= 3).",
  "The pattern text is a JSON string: escape backslashes as \\\\ . Test every change with test/run-tests.html.",
  "Weights: no single category reaches 5 alone; real ClickFix payloads hit three or more. See README 'Shipped rules'.",
  "The self-test rules exist so the pipeline can be verified end to end without any real payload; keep them."
]

out = sys.argv[1] if len(sys.argv) > 1 else 'rules.json'
with open(out, 'w', encoding='utf-8') as f:
    json.dump({"_comment": comment, "rules": rules, "combos": combos}, f, indent=2, ensure_ascii=True)
    f.write('\n')
print(len(rules), 'rules,', len(combos), 'combos')
