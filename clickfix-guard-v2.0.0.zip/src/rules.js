/* ClickFix Guard - rules.js
 *
 * Each rule adds its weight when its pattern (JS regex source, case-insensitive)
 * matches the normalised clipboard text; each combo adds its weight when all of
 * its rules matched. A copy scoring 5 or more is blocked. No single family reaches
 * 5 on its own; real ClickFix payloads hit three or more. The selftest rule blocks
 * the token CLICKFIX-GUARD-SELFTEST-CLIPBOARD, for checking a deployment.
 */
globalThis.__ClickFixRules = {
  "rules": [
    {
      "id": "selftest",
      "weight": 10,
      "pattern": "CLICKFIX-GUARD-SELFTEST-CLIPBOARD"
    },
    {
      "id": "lolbin-powershell",
      "weight": 2,
      "pattern": "\\b(?:powershell|pwsh)(?:\\.exe)?\\b"
    },
    {
      "id": "lolbin-mshta",
      "weight": 3,
      "pattern": "\\bmshta(?:\\.exe)?\\b"
    },
    {
      "id": "lolbin-rare",
      "weight": 2,
      "pattern": "\\b(?:rundll32|regsvr32|certutil|bitsadmin|wscript|cscript|forfiles|conhost|finger|cmstp|installutil|regasm|regsvcs|msbuild|odbcconf|pcalua|scriptrunner|syncappvpublishingserver|msxsl|wmic|cmdl32|ieexec|presentationhost|msdt)(?:\\.exe|\\.vbs)?\\b"
    },
    {
      "id": "lolbin-cmd",
      "weight": 1,
      "pattern": "\\bcmd(?:\\.exe)?\\s+/[ckr]\\b"
    },
    {
      "id": "lolbin-macos",
      "weight": 2,
      "pattern": "\\b(?:osascript|xattr|launchctl|dscl)\\b|\\bsecurity\\s+(?:find-generic-password|dump-keychain)\\b"
    },
    {
      "id": "lolbin-script-host",
      "weight": 1,
      "pattern": "\\b(?:python[0-9.]*|perl|ruby|node)(?:\\.exe)?\\s+-[ce]\\b"
    },
    {
      "id": "remote-url",
      "weight": 2,
      "pattern": "\\b(?:https?|ftp)://"
    },
    {
      "id": "remote-unc",
      "weight": 2,
      "pattern": "\\\\\\\\[a-z0-9.-]+(?:@(?:ssl|\\d+))*\\\\[^\\s]"
    },
    {
      "id": "remote-bare-ip",
      "weight": 2,
      "pattern": "(?<![\\d.])(?!(?:10|127|0)\\.|192\\.168\\.|172\\.(?:1[6-9]|2\\d|3[01])\\.)(?:(?:25[0-5]|2[0-4]\\d|1?\\d?\\d)\\.){3}(?:25[0-5]|2[0-4]\\d|1?\\d?\\d)(?![\\d]|\\.\\d)"
    },
    {
      "id": "hide-window",
      "weight": 2,
      "pattern": "(?:^|\\s)[-/\\u2013\\u2014]w(?:i(?:n(?:d(?:o(?:w(?:s(?:t(?:y(?:l(?:e)?)?)?)?)?)?)?)?)?)?\\s+(?:h(?:i(?:d(?:d(?:e(?:n)?)?)?)?)?|1|min(?:i(?:m(?:i(?:z(?:e(?:d)?)?)?)?)?)?)\\b|\\bconhost(?:\\.exe)?\\s+--headless\\b|\\bstart\\s+(?:\\\"[^\\\"]*\\\"\\s+)?/min\\b|\\bvbhide\\b"
    },
    {
      "id": "policy-bypass",
      "weight": 1,
      "pattern": "(?:^|\\s)[-/\\u2013\\u2014]e[a-z]*\\s+(?:bypass|unrestricted)\\b|(?:^|\\s)[-/\\u2013\\u2014]no(?:p|ni)[a-z]*\\b"
    },
    {
      "id": "encoded-command",
      "weight": 3,
      "pattern": "(?:^|\\s)[-/\\u2013\\u2014]e(?:c|n[a-z]*)?\\s+[a-z0-9+/]{40,}={0,2}(?=$|[\\s\\\"';|)])"
    },
    {
      "id": "long-base64-blob",
      "weight": 1,
      "pattern": "[a-z0-9+/]{120,}={0,2}"
    },
    {
      "id": "download-cmdlet",
      "weight": 1,
      "pattern": "\\b(?:iwr|irm|invoke-webrequest|invoke-restmethod|start-bitstransfer|wget|curl(?:\\.exe)?|downloadstring|downloadfile|downloaddata|net\\.webclient|webclient|system\\.net\\.http\\.httpclient|msxml2\\.xmlhttp|winhttp\\.winhttprequest)\\b"
    },
    {
      "id": "execute-cmdlet",
      "weight": 2,
      "pattern": "\\b(?:iex|invoke-expression)\\b|\\[scriptblock\\]::create|\\.invokescript\\(|(?:^|[\\s;(|])[.&]\\s*\\(\\s*(?:\\$|\\[|gcm\\b|get-command\\b)|\\bgcm\\s+\\S*\\*|\\binvoke-command\\s+-scriptblock"
    },
    {
      "id": "pipe-to-shell",
      "weight": 1,
      "pattern": "\\|\\s*(?:/(?:usr/)?bin/)?(?:ba|z|da|k)?sh\\b|\\|\\s*(?:powershell|pwsh|cmd|python[0-9.]*|perl|ruby|osascript)(?:\\.exe)?\\b"
    },
    {
      "id": "shell-subst-download",
      "weight": 1,
      "pattern": "\\b(?:ba|z)?sh\\s+-c\\s+[\\\"']?\\$\\(\\s*(?:curl|wget)\\b"
    },
    {
      "id": "write-then-run-temp",
      "weight": 1,
      "pattern": "%(?:temp|tmp|appdata|localappdata|public|programdata)%|\\$env:(?:temp|tmp|appdata|localappdata|public|programdata)\\b|\\\\users\\\\public\\\\|\\\\appdata\\\\(?:local|roaming)\\\\|(?:^|[\\s\\\"'])/(?:private/)?tmp/|\\[io\\.path\\]::gettemppath"
    },
    {
      "id": "msiexec-remote",
      "weight": 3,
      "pattern": "\\bmsiexec(?:\\.exe)?\\b.{0,40}?[\\s\\\"']/(?:i|package|y)\\s*[\\\"']?(?:https?://|\\\\\\\\)"
    },
    {
      "id": "certutil-fetch",
      "weight": 3,
      "pattern": "\\bcertutil(?:\\.exe)?\\b.{0,80}?[-/](?:urlcache|verifyctl|decode|decodehex)\\b"
    },
    {
      "id": "bitsadmin-transfer",
      "weight": 2,
      "pattern": "\\bbitsadmin(?:\\.exe)?\\b.{0,80}?/(?:transfer|addfile|create)\\b"
    },
    {
      "id": "regsvr32-scriptlet",
      "weight": 3,
      "pattern": "\\bregsvr32(?:\\.exe)?\\b.{0,80}?(?:/i:|scrobj)"
    },
    {
      "id": "rundll32-script",
      "weight": 3,
      "pattern": "\\brundll32(?:\\.exe)?\\b.{0,120}?(?:javascript:|vbscript:|mshtml|url\\.dll|ieframe\\.dll|shell32\\.dll\\s*,\\s*shellexec_rundll|davclnt\\.dll|\\\\\\\\)"
    },
    {
      "id": "finger-fetch",
      "weight": 3,
      "pattern": "\\bfinger(?:\\.exe)?\\s+\\S+@\\S+"
    },
    {
      "id": "nslookup-stager",
      "weight": 3,
      "pattern": "\\bnslookup\\b[^|]{0,120}\\|"
    },
    {
      "id": "wmic-process-create",
      "weight": 2,
      "pattern": "\\bwmic\\b.{0,60}?\\bprocess\\s+call\\s+create\\b"
    },
    {
      "id": "defender-tamper",
      "weight": 3,
      "pattern": "\\b(?:add|set)-mppreference\\b.{0,80}?[-/\\u2013\\u2014](?:exclusion|disable)"
    },
    {
      "id": "macos-quarantine-strip",
      "weight": 3,
      "pattern": "\\bxattr\\s+-(?:c|r?d)\\b|com\\.apple\\.quarantine"
    },
    {
      "id": "macos-download-exec",
      "weight": 2,
      "pattern": "\\b(?:curl|wget)\\b.{0,200}?(?:&&|;)\\s*(?:chmod\\s+\\+x|open\\s|\\./|/tmp/)"
    },
    {
      "id": "obf-char-cast",
      "weight": 2,
      "pattern": "\\[char\\]\\s*\\(?\\s*(?:0x[0-9a-f]+|\\d+)|\\[char\\[\\]\\]"
    },
    {
      "id": "obf-reverse-join",
      "weight": 2,
      "pattern": "\\[array\\]::reverse|-join\\s*\\(?\\s*\\[char|\\[regex\\]::matches\\([^)]*righttoleft|\\[string\\]::join\\(\\s*[\\\"']{2}"
    },
    {
      "id": "obf-string-ops",
      "weight": 1,
      "pattern": "(?:^|\\s)-(?:join|replace|split)\\b|\\.replace\\(|\\s-f\\s+[\\\"']"
    },
    {
      "id": "obf-base64-decode",
      "weight": 2,
      "pattern": "frombase64string|\\[(?:system\\.)?text\\.encoding\\]::|\\bbase64\\s+(?:-d|--decode|-D)\\b|\\batob\\s*\\(|\\bopenssl\\s+(?:base64|enc)\\s+-d\\b"
    },
    {
      "id": "obf-env-slice",
      "weight": 2,
      "pattern": "\\$env:comspec\\[|\\$pshome\\[|\\$shellid\\[|\\$verbosepreference\\.tostring\\(\\)|\\(\\s*\\$env:public\\s*\\)\\["
    },
    {
      "id": "obf-wildcard-exe",
      "weight": 3,
      "pattern": "[a-z]:\\\\(?:[^\\\\\\s\\\"']*\\\\)*[^\\\\\\s\\\"']*\\*[^\\\\\\s\\\"']*\\.exe"
    },
    {
      "id": "base64-pipe-shell",
      "weight": 3,
      "pattern": "\\bbase64\\s+(?:-d|--decode|-D)\\b[^|]{0,40}\\|\\s*(?:/(?:usr/)?bin/)?(?:ba|z)?sh\\b"
    },
    {
      "id": "decoy-comment",
      "weight": 3,
      "pattern": "(?:^|[\\s;&|\\\"'])(?:#|::|rem\\s|//|<#).{0,160}?(?:not\\s+a\\s+robot|i\\s*'?\\s*a?m\\s+(?:a\\s+)?human|human\\s+(?:verification|check)|captcha|cloudflare|ray[\\s-]*id|verif(?:y|ied|ication)|security\\s+check|validation|authenticat|confirm|\\bfix\\b|turnstile|[\\u2713\\u2714\\u2705\\u2611])"
    },
    {
      "id": "decoy-filefix-path",
      "weight": 3,
      "pattern": "#\\s*[\\\"']?[a-z]:\\\\[^#]{0,200}?\\.(?:docx?|pdf|xlsx?|pptx?|txt|csv)\\b"
    }
  ],
  "combos": [
    {
      "id": "combo-mshta-remote",
      "weight": 2,
      "all": [
        "lolbin-mshta",
        "remote-url"
      ]
    },
    {
      "id": "combo-powershell-remote",
      "weight": 1,
      "all": [
        "lolbin-powershell",
        "remote-url"
      ]
    },
    {
      "id": "combo-rare-remote",
      "weight": 1,
      "all": [
        "lolbin-rare",
        "remote-url"
      ]
    },
    {
      "id": "combo-download-cradle",
      "weight": 1,
      "all": [
        "download-cmdlet",
        "execute-cmdlet"
      ]
    },
    {
      "id": "combo-hidden-powershell",
      "weight": 1,
      "all": [
        "lolbin-powershell",
        "hide-window"
      ]
    }
  ]
};
