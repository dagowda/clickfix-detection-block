/* ClickFix Guard - background.js (MV3 service worker)
 *
 * - Registers the page hooks in every frame of every page, minus allow-listed
 *   domains (excludeMatches), so pages never have to ask for configuration.
 * - Records blocks reported by bridge.js: badge count, desktop notification,
 *   last 100 kept for the popup.
 * It sleeps until the allow-list changes or a page is blocked.
 */
'use strict';

const MAX_RECORDS = 100;
// Domains (and their subdomains) never hooked, on every install. Add one per line,
// then reload the extension. Per-browser additions go in the options page, fleet-wide
// ones in the allowDomains policy.
const BUILT_IN_ALLOW = [
  'sentinelone.com'
];
const COMMON = {
  matches: ['<all_urls>'],
  allFrames: true,
  matchOriginAsFallback: true,
  runAt: 'document_start',
  persistAcrossSessions: true
};
const SCRIPTS = [
  { id: 'clickfix-hook', js: ['src/rules.js', 'src/detector.js', 'src/hook.js'], world: 'MAIN' },
  { id: 'clickfix-bridge', js: ['src/bridge.js'], world: 'ISOLATED' }
];

// One chain per kind of write so overlapping events never interleave.
function serial() {
  let tail = Promise.resolve();
  return (fn) => (tail = tail.then(fn, fn).catch((e) => console.warn('ClickFix Guard:', e)));
}
const scriptQueue = serial();
const recordQueue = serial();

async function storageGet(area, key) {
  try { return (await chrome.storage[area].get(key))[key]; } catch (e) { return undefined; }
}

// Built-in list, plus policy (chrome.storage.managed), plus the options page.
async function allowDomains() {
  const list = [].concat(BUILT_IN_ALLOW, (await storageGet('managed', 'allowDomains')) || [],
    (await storageGet('local', 'allowDomains')) || []);
  const out = new Set();
  for (let d of list) {
    d = String(d || '').trim().toLowerCase()
      .replace(/^[a-z]+:\/\//, '').replace(/[/:].*$/, '').replace(/^\*?\./, '');
    // An invalid match pattern makes registration fail for everything, so keep only plain hostnames.
    if (/^[a-z0-9-]+(?:\.[a-z0-9-]+)*$/.test(d)) out.add(d);
  }
  return [...out];
}

function syncScripts() {
  return scriptQueue(async () => {
    const domains = await allowDomains();
    const excludeMatches = domains.flatMap((d) => ['*://' + d + '/*', '*://*.' + d + '/*']);
    const registered = new Set((await chrome.scripting.getRegisteredContentScripts()).map((s) => s.id));
    const apply = async (specs) => {
      const update = specs.filter((s) => registered.has(s.id));
      const add = specs.filter((s) => !registered.has(s.id));
      if (update.length) await chrome.scripting.updateContentScripts(update);
      if (add.length) await chrome.scripting.registerContentScripts(add);
    };
    const specs = SCRIPTS.map((s) => Object.assign({}, COMMON, s, { excludeMatches }));
    try {
      await apply(specs);
    } catch (e) {
      // Chrome before 119 has no matchOriginAsFallback for dynamic scripts.
      await apply(specs.map(({ matchOriginAsFallback, ...s }) => s));
    }
  });
}

function hostOf(url) {
  try { return new URL(url).hostname; } catch (e) { return ''; }
}

const lastNotified = new Map(); // tabId -> time, so a page copying twice raises one notification

function record(msg, sender) {
  return recordQueue(async () => {
    const tab = sender.tab || {};
    const rec = {
      ts: new Date().toISOString(),
      url: tab.url || msg.frameUrl || '',
      frameUrl: msg.frameUrl || '',
      method: msg.method,
      score: msg.score,
      signals: msg.signals,
      sample: msg.sample
    };
    const list = (await storageGet('local', 'detections')) || [];
    list.unshift(rec);
    list.length = Math.min(list.length, MAX_RECORDS);
    const unread = ((await storageGet('local', 'unread')) || 0) + 1;
    await chrome.storage.local.set({ detections: list, unread });
    await chrome.action.setBadgeBackgroundColor({ color: '#b3261e' });
    await chrome.action.setBadgeText({ text: unread > 99 ? '99+' : String(unread) });

    const now = Date.now();
    if (now - (lastNotified.get(tab.id) || 0) > 10000) {
      lastNotified.set(tab.id, now);
      chrome.notifications.create({
        type: 'basic',
        iconUrl: chrome.runtime.getURL('icons/icon128.png'),
        title: 'ClickFix Guard blocked a malicious command',
        message: (hostOf(rec.url) || 'A web page') +
          ' tried to copy a hidden command to your clipboard. Nothing harmful was copied. Do not follow its instructions.',
        priority: 2
      });
    }
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || sender.id !== chrome.runtime.id) return false;
  if (msg.type === 'blocked' && sender.tab) {
    record(msg, sender);
    return false;
  }
  if (msg.type === 'list') {
    recordQueue(async () => {
      await chrome.storage.local.set({ unread: 0 });
      await chrome.action.setBadgeText({ text: '' });
      sendResponse({ detections: (await storageGet('local', 'detections')) || [] });
    });
    return true;
  }
  if (msg.type === 'clear') {
    recordQueue(async () => {
      await chrome.storage.local.set({ detections: [], unread: 0 });
      await chrome.action.setBadgeText({ text: '' });
      sendResponse({ ok: true });
    });
    return true;
  }
  return false;
});

chrome.storage.onChanged.addListener((changes) => {
  if (changes.allowDomains) syncScripts();
});
chrome.runtime.onInstalled.addListener(syncScripts);
chrome.runtime.onStartup.addListener(syncScripts);
