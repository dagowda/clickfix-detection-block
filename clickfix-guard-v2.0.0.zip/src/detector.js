/* ClickFix Guard - detector.js
 *
 * Weighted-rules scoring engine, loaded into the page's MAIN world before
 * hook.js, which takes it and deletes the global.
 *
 * Rules are data (rules.js). Each rule:
 *   { id, weight, pattern, flags? }       combos: { id, weight, all: [rule ids] }
 * loadRules(def) compiles them; score(text) -> { score, signals[] }.
 * A copy is a ClickFix payload when score >= THRESHOLD.
 */
globalThis.__ClickFixDetector = (() => {
  'use strict';

  const THRESHOLD = 5;
  // Normalised characters scored per copy. Longer text is scored on its head and
  // tail halves so a huge copy cannot stall the page; whitespace padding is
  // collapsed before this cut, so padding cannot push a payload out of range.
  const MAX_SCAN = 16384;

  let rules = [];
  let combos = [];

  function compile(rule) {
    try {
      const flags = String(rule.flags || 'i').replace(/g/g, ''); // never global: .test() must be stateless
      return { id: String(rule.id), w: Number(rule.weight) || 0, re: new RegExp(rule.pattern, flags) };
    } catch (e) {
      return null; // bad pattern: skip it rather than break the engine
    }
  }

  function loadRules(def) {
    def = def || {};
    rules = (Array.isArray(def.rules) ? def.rules : []).filter(Boolean).map(compile).filter(Boolean);
    combos = (Array.isArray(def.combos) ? def.combos : [])
      .filter(c => c && Array.isArray(c.all) && c.all.length)
      .map(c => ({ id: String(c.id), w: Number(c.weight) || 0, all: c.all.map(String) }));
    return { rules: rules.length, combos: combos.length };
  }

  // Undo the cheap tricks used to break naive string matching.
  function normalize(raw) {
    return String(raw)
      .replace(/[\u200B-\u200F\u2028\u2029\uFEFF\u00AD]/g, '') // zero-width chars, soft hyphen
      .replace(/\^/g, '')                                      // cmd.exe caret escaping
      .replace(/`/g, '')                                       // PowerShell backtick escaping
      .replace(/["']\s*\+\s*["']/g, '')                        // "ab"+"cd" string splitting
      .replace(/\s+/g, ' ');
  }

  function score(text) {
    const raw = text == null ? '' : String(text);
    const signals = [];
    let total = 0;
    if (!raw.trim()) return { score: 0, signals };

    let norm = normalize(raw);
    if (norm.length > MAX_SCAN) norm = norm.slice(0, MAX_SCAN / 2) + ' ' + norm.slice(-MAX_SCAN / 2);
    for (const r of rules) {
      if (r.re.test(norm)) { signals.push(r.id); total += r.w; }
    }
    // Long runs of whitespace push the real command out of view in a one-line input.
    if (/[ \t]{10,}|(?:\r?\n){3,}/.test(raw)) { signals.push('whitespace-padding'); total += 1; }

    for (const c of combos) {
      if (c.all.every(id => signals.includes(id))) { signals.push(c.id); total += c.w; }
    }
    return { score: total, signals };
  }

  return { THRESHOLD, loadRules, score };
})();
