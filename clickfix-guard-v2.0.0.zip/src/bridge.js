/* ClickFix Guard - bridge.js  (isolated world, document_start, every frame)
 *
 * Forwards block reports from hook.js to the service worker. Idle until a block
 * happens. A page can fire the same DOM event itself, so reports are capped.
 */
(() => {
  'use strict';
  let sent = 0;
  document.addEventListener('clickfix-guard:blocked', (e) => {
    if (sent >= 20) return;
    let d;
    try { d = JSON.parse(e.detail); } catch (err) { return; }
    if (!d || typeof d !== 'object') return;
    sent++;
    try {
      chrome.runtime.sendMessage({
        type: 'blocked',
        method: String(d.method || '').slice(0, 40),
        score: Number(d.score) || 0,
        signals: Array.isArray(d.signals) ? d.signals.slice(0, 40).map(String) : [],
        sample: String(d.sample || '').slice(0, 200),
        frameUrl: location.href
      }, () => void chrome.runtime.lastError);
    } catch (err) { /* extension reloaded: nothing to report to */ }
  }, true);
})();
