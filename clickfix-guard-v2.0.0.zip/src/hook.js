/* ClickFix Guard - hook.js  (page MAIN world, document_start, every frame)
 *
 * Wraps the four ways a page can put text on the clipboard and swaps a ClickFix
 * payload for a warning before it lands:
 *   Clipboard.prototype.writeText / write
 *   Document.prototype.execCommand('copy' | 'cut')
 *   DataTransfer.prototype.setData   (copy / cut / drag handlers)
 * Page load cost is installing the wrappers, nothing else: the rules compile on
 * the first clipboard write, and blocks are reported to bridge.js afterwards so
 * the clipboard call itself never waits on the extension.
 */
(() => {
  'use strict';
  const D = globalThis.__ClickFixDetector;
  const RULES = globalThis.__ClickFixRules;
  try { delete globalThis.__ClickFixDetector; delete globalThis.__ClickFixRules; } catch (e) { /* ignore */ }
  if (!D || !RULES) return;

  const EVT = 'clickfix-guard:blocked';
  const WARNING =
    'BLOCKED by ClickFix Guard: the website you were on tried to copy a hidden command to your clipboard ' +
    '(ClickFix attack). Do not paste it anywhere. Close the page and report it to your IT security team.';
  const setTimeoutNative = setTimeout;
  const dispatch = EventTarget.prototype.dispatchEvent;
  const NativeCustomEvent = CustomEvent;
  let loaded = false;

  // true when the text is a ClickFix payload and must be replaced
  function blocked(text, method) {
    if (typeof text !== 'string' || text.length < 8) return false;
    if (!loaded) { D.loadRules(RULES); loaded = true; }
    const r = D.score(text);
    if (r.score < D.THRESHOLD) return false;
    const detail = JSON.stringify({ method, score: r.score, signals: r.signals, sample: text.slice(0, 200) });
    setTimeoutNative(() => {
      try { dispatch.call(document, new NativeCustomEvent(EVT, { detail })); } catch (e) { /* ignore */ }
    }, 0);
    return true;
  }

  function selectedText(doc) {
    try {
      const el = doc.activeElement;
      if (el && (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') && typeof el.value === 'string') {
        const s = el.selectionStart, e = el.selectionEnd;
        return (s != null && e != null && e > s) ? el.value.slice(s, e) : el.value;
      }
      const sel = doc.getSelection && doc.getSelection();
      return sel ? sel.toString() : '';
    } catch (e) { return ''; }
  }

  function textFromHtml(html) {
    return String(html).replace(/<[^>]*>/g, ' ');
  }

  function define(proto, name, fn, orig) {
    try {
      Object.defineProperty(fn, 'name', { value: name });
      Object.defineProperty(fn, 'length', { value: orig.length });
      Object.defineProperty(proto, name, { value: fn, writable: true, configurable: true });
    } catch (e) { proto[name] = fn; }
  }

  // DataTransfer and Document exist everywhere; Clipboard only in secure contexts,
  // so each API is wrapped on its own and a missing one never disables the rest.
  const origSetData = DataTransfer.prototype.setData;
  define(DataTransfer.prototype, 'setData', function setData(format, data) {
    if (typeof data === 'string' && /text/i.test(String(format))) {
      const text = /html/i.test(String(format)) ? textFromHtml(data) : data;
      if (blocked(text, 'clipboardData.setData')) return origSetData.call(this, format, WARNING);
    }
    return origSetData.call(this, format, data);
  }, origSetData);

  const origExec = Document.prototype.execCommand;
  define(Document.prototype, 'execCommand', function execCommand(cmd) {
    if (typeof cmd === 'string' && /^(?:copy|cut)$/i.test(cmd) && blocked(selectedText(this), 'execCommand(' + cmd + ')')) {
      // A capture listener on window runs before any page handler, so it owns
      // the clipboard payload for this one event.
      const win = this.defaultView || globalThis;
      const type = cmd.toLowerCase();
      const own = (ev) => {
        ev.stopImmediatePropagation();
        ev.preventDefault();
        if (ev.clipboardData) origSetData.call(ev.clipboardData, 'text/plain', WARNING);
      };
      win.addEventListener(type, own, { capture: true, once: true });
      try { return origExec.apply(this, arguments); }
      finally { win.removeEventListener(type, own, { capture: true }); }
    }
    return origExec.apply(this, arguments);
  }, origExec);

  if (typeof Clipboard === 'undefined') return;

  const origWriteText = Clipboard.prototype.writeText;
  define(Clipboard.prototype, 'writeText', function writeText(text) {
    return origWriteText.call(this, blocked(String(text), 'clipboard.writeText') ? WARNING : text);
  }, origWriteText);

  const origWrite = Clipboard.prototype.write;
  define(Clipboard.prototype, 'write', async function write(items) {
    try {
      for (const item of Array.from(items || [])) {
        for (const type of (item && item.types) || []) {
          if (type !== 'text/plain' && type !== 'text/html') continue;
          let text = await (await item.getType(type)).text();
          if (type === 'text/html') text = textFromHtml(text);
          if (blocked(text, 'clipboard.write[' + type + ']')) return origWriteText.call(this, WARNING);
        }
      }
    } catch (e) { /* unreadable item: fall through to the original */ }
    return origWrite.call(this, items);
  }, origWrite);
})();
