'use strict';

const box = document.getElementById('domains');
const status = document.getElementById('status');

async function load() {
  const local = await chrome.storage.local.get('allowDomains');
  box.value = (local.allowDomains || []).join('\n');
  try {
    const managed = await chrome.storage.managed.get('allowDomains');
    if (managed.allowDomains && managed.allowDomains.length) {
      const m = document.getElementById('managed');
      m.hidden = false;
      m.textContent = 'Also allowed by enterprise policy:\n' + managed.allowDomains.join('\n');
    }
  } catch (e) { /* no policy */ }
}

document.getElementById('save').addEventListener('click', async () => {
  const allowDomains = box.value.split(/[\s,;]+/).map((s) => s.trim()).filter(Boolean);
  await chrome.storage.local.set({ allowDomains });
  status.textContent = 'Saved';
  setTimeout(() => { status.textContent = ''; }, 2500);
});

load();
