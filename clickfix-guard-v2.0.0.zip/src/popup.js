'use strict';

function send(msg) {
  return new Promise((resolve) => chrome.runtime.sendMessage(msg, (r) => resolve(chrome.runtime.lastError ? null : r)));
}
function hostOf(u) { try { return new URL(u).hostname || u; } catch (e) { return u || '(unknown)'; } }
function ago(iso) {
  const s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return Math.round(s) + 's ago';
  if (s < 3600) return Math.round(s / 60) + 'm ago';
  if (s < 86400) return Math.round(s / 3600) + 'h ago';
  return Math.round(s / 86400) + 'd ago';
}
function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}

async function render() {
  const r = await send({ type: 'list' });
  const items = (r && r.detections) || [];
  const list = document.getElementById('list');
  list.textContent = '';
  if (!items.length) { list.appendChild(el('div', 'empty', 'No ClickFix attempts blocked on this browser.')); return; }
  for (const d of items) {
    const rec = el('div', 'rec');
    const top = el('div', 'top');
    top.appendChild(el('span', 'host', hostOf(d.url)));
    top.appendChild(el('span', 'tag', 'blocked | score ' + d.score));
    top.appendChild(el('span', 'when', ago(d.ts)));
    rec.appendChild(top);
    rec.appendChild(el('div', 'sig', d.method + ' | ' + (d.signals || []).join(', ')));
    rec.appendChild(el('div', 'sample', d.sample || ''));
    list.appendChild(rec);
  }
}

document.getElementById('options').addEventListener('click', () => chrome.runtime.openOptionsPage());
document.getElementById('clear').addEventListener('click', async () => { await send({ type: 'clear' }); render(); });
render();
